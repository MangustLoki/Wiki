# Village Houses

Village houses spawn in adverse areas where Villages don't.

## Mountain House

![](https://imgur.com/FaxDo6B.png)

Mountain houses spawn on rocky mountains. Some amount of area correction will occur for mountain houses because mountains are especially uneven and bad for houses. Schematic donated by [ddddddnikita](https://www.spigotmc.org/members/ddddddnikita.841616/)

## Farmhouse

![](https://imgur.com/uNgGO1g.png)
![](https://imgur.com/Wo4m3yd.png)
![](https://imgur.com/D03ELK2.png)

Spawns a schematic house with some randomisations (cobblestone randomised with mossy cobblestone, different wood variants, chests in different areas etc). Around the house, some farmlands are spawned, with paths and campfire lamps. Spawns 2 villagers and a cat. The house will always spawn a log base to elevate it from the ground.

## Animal Farm

![](https://imgur.com/yi7gOVG.png)

Spawns a schematic house that is surrounded by animal pens. The animal pens are notorious for spawning in stupid locations, so please do report any weirdness if you find it. 
