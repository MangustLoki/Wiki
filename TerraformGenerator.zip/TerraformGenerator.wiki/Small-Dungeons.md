# Small Dungeons 

## Underground Dungeon

![](https://imgur.com/rba0V42.png)

Can spawn anywhere. Your standard skeleton/spider/zombie dungeon. Spawns mossy cobblestone and fences. Commonly exposed in large caves.

## Drowned Dungeon

![](https://imgur.com/xGvZ120.png)

Has a chance to spawn when the ground level is below the config value. Spawns small spires and one drowned spawner, along with some magma, kelp and sea grass.