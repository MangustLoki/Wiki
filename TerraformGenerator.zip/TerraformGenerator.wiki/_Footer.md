If you like the plugin, please consider supporting me by donating on [Paypal](https://paypal.me/leonardrfong). If you want to receive support, go ahead and join our [Discord.](https://discord.gg/yW7JcqM)

<a href= "https://discord.gg/yW7JcqM" target="__blank">
<img alt="TerraformGenerator's Discord" src="https://discord.com/assets/cb48d2a8d4991281d7a6a95d2f58195e.svg" width="200"></a> 
<a href= "https://paypal.me/leonardrfong" target="__blank">
<img alt="Paypal Donation Link" src="https://1000logos.net/wp-content/uploads/2017/05/Paypal-Logo.png" width="200">
</a>