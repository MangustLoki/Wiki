# Outposts

![](https://imgur.com/WlTTIkL.png)
![](https://imgur.com/L7w3X83.png)

Spawns a core watchtower that consists of 3 schematics, then populates the close surroundings with procedural tents, campfires, cages and log piles. The entire area is then surrounded with a stake wall