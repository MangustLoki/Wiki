![trailruins](https://github.com/user-attachments/assets/07ffcbbb-7699-4ffc-98a8-69a553efc056)

Similar to the vanilla structure. Spawns suspicious gravel.