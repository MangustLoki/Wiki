# Igloo

![](https://imgur.com/ybaWuYB.png)
Can spawn in snowy biomes. These currently have no creepy villager dungeon basement.