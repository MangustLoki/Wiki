# Structure List

These structures are fully custom compared to vanilla

*[Trail Ruins](https://github.com/Hex27/TerraformGenerator/wiki/Trail-Ruins)
* [Ancient Cities](https://github.com/Hex27/TerraformGenerator/wiki/Ancient-City)
* [Large Caves](https://github.com/Hex27/TerraformGenerator/wiki/Large-Caves)
* [Catacombs](https://github.com/Hex27/TerraformGenerator/wiki/Catacombs)
* [Mansions](https://github.com/Hex27/TerraformGenerator/wiki/Mansions)
* [Mineshafts](https://github.com/Hex27/TerraformGenerator/wiki/Mineshafts)
* [Monuments](https://github.com/Hex27/TerraformGenerator/wiki/Monuments)
* [Outposts](https://github.com/Hex27/TerraformGenerator/wiki/Outposts)
* [Pyramids](https://github.com/Hex27/TerraformGenerator/wiki/Pyramids)
* [Small Dungeons](https://github.com/Hex27/TerraformGenerator/wiki/Small-Dungeons)
* [Strongholds](https://github.com/Hex27/TerraformGenerator/wiki/Strongholds)
* [Village Houses](https://github.com/Hex27/TerraformGenerator/wiki/Village-Houses)
* [Villages](https://github.com/Hex27/TerraformGenerator/wiki/Villages)
* [Igloo](https://github.com/Hex27/TerraformGenerator/wiki/Igloo)

# Vanilla Structures

TerraformGenerator will generate the following vanilla structures as they are in the base game.

* Trial Chambers